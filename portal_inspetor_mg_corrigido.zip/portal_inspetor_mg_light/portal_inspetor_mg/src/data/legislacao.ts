import { LegislacaoDocumento } from "@/types/legislacao";

export const legislacaoData: LegislacaoDocumento[] = [
  {
    id: "resolucao-see-4943-2023",
    titulo: "Resolução SEE Nº 4.943/2023",
    ementa: "Dispõe sobre a organização e o funcionamento do ensino nas Escolas Estaduais de Educação Básica de Minas Gerais.",
    data: "2023-12-20",
    tipo: "Resolução SEE",
    tema: "Organização Escolar",
    ano: 2023,
    linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2023/12/4943-23-r-Public.-20-12-23.pdf",
    // linkLocal: "/legislacao_mg/Resolucao_SEE_4943_2023.pdf" // Local link can be added if files are served
  },
  {
    id: "resolucao-cee-495-2023",
    titulo: "Resolução CEE Nº 495/2023",
    ementa: "Fixa normas para autorização de funcionamento e supervisão de instituições de Educação Básica e suas modalidades, integrantes do Sistema de Ensino de Minas Gerais.",
    data: "2023-12-28", // Assuming publication date based on similar documents, needs verification
    tipo: "Resolução CEE",
    tema: "Autorização de Funcionamento",
    ano: 2023,
    linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2025/01/SEI_GOVMG-Resolucao-495-2024.pdf", // Note: Filename says 2024, but content refers to 495/2023
    // linkLocal: "/legislacao_mg/Resolucao_CEE_495_2023.pdf"
  },
  {
    id: "retificacao-resolucao-see-4919-2023",
    titulo: "Retificação da Resolução SEE Nº 4.919/2023",
    ementa: "Retifica a Resolução SEE Nº 4.919, de 11 de outubro de 2023, que dispõe sobre a organização e o funcionamento da Inspeção Escolar no Sistema de Ensino de Minas Gerais.",
    data: "2024-05-09",
    tipo: "Retificação Resolução SEE",
    tema: "Inspeção Escolar",
    ano: 2024,
    linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2024/05/Retificacao-da-Resolucao-SEE-no-4919-2023-Public.-09-05-24.pdf",
    // linkLocal: "/legislacao_mg/Retificacao_Resolucao_SEE_4919_2023.pdf"
  },
   {
    id: "portaria-see-812-2025",
    titulo: "Portaria SEE Nº 812/2025",
    ementa: "Dispõe sobre a organização e o funcionamento do Atendimento Educacional Especializado (AEE) na rede estadual de ensino de Minas Gerais.", // Ementa inferred, needs verification
    data: "2025-04-XX", // Date needs verification from document
    tipo: "Portaria SEE",
    tema: "Educação Especial",
    ano: 2025,
    linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2025/04/812-25-P.pdf",
    // linkLocal: "/legislacao_mg/Portaria_SEE_812_2025.pdf"
  },
  {
    id: "instrucao-normativa-sa-see-3-2025",
    titulo: "Instrução Normativa SA/SEE Nº 3/2025",
    ementa: "Estabelece procedimentos para a contratação temporária de Professor de Educação Básica - PEB Regente de Aulas para atuação nos Anos Finais do Ensino Fundamental e Ensino Médio...", // Ementa needs verification
    data: "2025-04-XX", // Date needs verification from document
    tipo: "Instrução Normativa",
    tema: "Gestão de Pessoas", // Theme inferred, needs verification
    ano: 2025,
    linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2025/04/SEI_110946993_Instrucao_SEE_n__3_2025.pdf",
    // linkLocal: "/legislacao_mg/Instrucao_Normativa_SA_SEE_3_2025.pdf"
  },
  // Add more documents here as identified
];


export interface LegislacaoDocumento {
  id: string;
  titulo: string;
  ementa: string;
  data: string; // Format YYYY-MM-DD or descriptive string if exact date unknown
  tipo: string; // e.g., "Resolução SEE", "Resolução CEE", "Lei", "Portaria", "Retificação"
  tema: string; // e.g., "Organização Escolar", "Autorização de Funcionamento"
  ano: number;
  linkOficial?: string; // URL for the official source
  linkLocal?: string; // Path to a locally stored PDF (relative to public folder or handled via API route)
  // Add other relevant fields if needed, like keywords
}

// Example usage (will be moved to a data file)
// const exemplo: LegislacaoDocumento = {
//   id: "resolucao-see-4943-2023",
//   titulo: "Resolução SEE Nº 4.943/2023",
//   ementa: "Dispõe sobre a organização e o funcionamento do ensino nas Escolas Estaduais de Educação Básica de Minas Gerais.",
//   data: "2023-12-20",
//   tipo: "Resolução SEE",
//   tema: "Organização Escolar",
//   ano: 2023,
//   linkOficial: "https://www.educacao.mg.gov.br/wp-content/uploads/2023/12/4943-23-r-Public.-20-12-23.pdf",
//   linkLocal: "/legislacao_mg/Resolucao_SEE_4943_2023.pdf"
// };


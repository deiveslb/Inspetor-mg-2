import type { Metadata } from "next";
import Link from 'next/link';

export const metadata: Metadata = {
  title: "Diretrizes SRI | Portal do Inspetor Escolar - MG",
  description: "Acesse as diretrizes, orientações e documentos da Superintendência de Regulação e Inspeção Escolar (SRI) de Minas Gerais.",
};

export default function DiretrizesSRIPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Diretrizes da SRI</h1>
      
      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Sobre a SRI</h2>
        <p className="mb-3">
          A Superintendência de Regulação e Inspeção Escolar (SRI) é o órgão da Secretaria de Estado de Educação de Minas Gerais (SEE/MG) responsável por orientar, acompanhar e fiscalizar as instituições de ensino do sistema estadual, garantindo o cumprimento da legislação educacional e a qualidade dos serviços prestados.
        </p>
        <p>
          Nesta seção, você encontrará documentos normativos, orientações e informações relevantes emitidas pela SRI para apoiar o trabalho da Inspeção Escolar.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Documentos da SRI</h2>
        <p className="mb-4">Abaixo estão alguns dos documentos e orientações emitidos pela SRI. Para uma lista mais completa, consulte os links úteis.</p>
        <ul className="list-disc pl-5 space-y-2">
          <li>
            {/* Placeholder link - Actual document link might be different or require login */}
            <span className="font-semibold">Instrução Normativa SA/SEE Nº 3/2025:</span> (Documento baixado durante a pesquisa inicial - verificar disponibilidade de link público)
            {/* <Link href="/path/to/Instrucao_Normativa_SA_SEE_3_2025.pdf" className="text-blue-600 hover:underline ml-2">[Acessar PDF]</Link> */}
          </li>
          <li>
            <span className="font-semibold">Orientação de Serviço SRI Nº 02/2024:</span> Padroniza os processos para a regulamentação das instituições de educação básica nas redes municipal e privada. (Referência encontrada em notícias e na seção de Documentos Internos - link original apresentou erro 404 durante a pesquisa).
          </li>
           <li>
            <span className="font-semibold">Orientação Normativa SRI/VIDA ESCOLAR N° 01/2025:</span> Orienta sobre procedimentos específicos (Referência encontrada em pesquisa web - verificar disponibilidade de link público).
          </li>
          {/* Add more documents as they are identified and links become available */}
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-3">Links Úteis e Contato</h2>
        <ul className="list-disc pl-5 space-y-2 mb-4">
          <li>
            <Link href="https://www.educacao.mg.gov.br/servidor/inspecao-escolar/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Página de Inspeção Escolar (Site SEE/MG)
            </Link>
          </li>
          <li>
            <Link href="https://www.educacao.mg.gov.br/documentos-internos/?categoria=sri" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Documentos Internos da SRI (Site SEE/MG)
            </Link>
          </li>
        </ul>
        <div className="bg-gray-100 p-4 rounded border">
          <h3 className="font-semibold mb-1">Contato SRI</h3>
          <p>Telefone: (31) 3915-3309</p>
          <p>E-mail: sri@educacao.mg.gov.br</p>
        </div>
      </section>
    </div>
  );
}


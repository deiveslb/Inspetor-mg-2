'use client';

import type { Metadata } from "next";
import Link from 'next/link';
import { useState, useEffect } from 'react'; // Import useState and useEffect for client-side interactivity
import { legislacaoData } from '@/data/legislacao';
import { LegislacaoDocumento } from '@/types/legislacao';

// Metadata can be defined even in client components, but it's often better in layout or server components if static
// export const metadata: Metadata = {
//   title: "Legislação Educacional | Portal do Inspetor Escolar - MG",
//   description: "Consulte a legislação educacional de Minas Gerais: Leis, Decretos, Resoluções, Portarias e mais.",
// };

export default function LegislacaoPage() {
  const [tipoFiltro, setTipoFiltro] = useState('');
  const [temaFiltro, setTemaFiltro] = useState('');
  const [anoFiltro, setAnoFiltro] = useState('');
  const [buscaFiltro, setBuscaFiltro] = useState('');
  const [documentosFiltrados, setDocumentosFiltrados] = useState<LegislacaoDocumento[]>(legislacaoData);

  // Extract unique values for filters
  // These could be pre-calculated or derived server-side in a real app for performance
  const tiposUnicos = Array.from(new Set(legislacaoData.map(doc => doc.tipo))).sort();
  const temasUnicos = Array.from(new Set(legislacaoData.map(doc => doc.tema))).sort();
  const anosUnicos = Array.from(new Set(legislacaoData.map(doc => doc.ano))).sort((a, b) => b - a); // Sort descending

  useEffect(() => {
    let filtrados = legislacaoData;

    if (tipoFiltro) {
      filtrados = filtrados.filter(doc => doc.tipo === tipoFiltro);
    }
    if (temaFiltro) {
      filtrados = filtrados.filter(doc => doc.tema === temaFiltro);
    }
    if (anoFiltro) {
      filtrados = filtrados.filter(doc => doc.ano === parseInt(anoFiltro));
    }
    if (buscaFiltro) {
      const buscaLower = buscaFiltro.toLowerCase();
      filtrados = filtrados.filter(doc => 
        doc.titulo.toLowerCase().includes(buscaLower) || 
        doc.ementa.toLowerCase().includes(buscaLower)
      );
    }

    setDocumentosFiltrados(filtrados);
  }, [tipoFiltro, temaFiltro, anoFiltro, buscaFiltro]);

  return (
    <div>
      {/* Set title dynamically if needed, or use static metadata */}
      {/* <title>Legislação Educacional | Portal do Inspetor Escolar - MG</title> */}
      <h1 className="text-3xl font-bold mb-6">Legislação Educacional de MG</h1>
      <p className="mb-6">Consulte as principais normas que regem a educação básica em Minas Gerais. Utilize os filtros e a busca para encontrar documentos específicos.</p>

      {/* Filters and Search Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 p-4 border rounded bg-gray-50">
        <div>
          <label htmlFor="tipo" className="block text-sm font-medium text-gray-700 mb-1">Tipo:</label>
          <select 
            id="tipo" 
            name="tipo" 
            className="w-full p-2 border rounded" 
            value={tipoFiltro}
            onChange={(e) => setTipoFiltro(e.target.value)}
          >
            <option value="">Todos</option>
            {tiposUnicos.map(tipo => (
              <option key={tipo} value={tipo}>{tipo}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="tema" className="block text-sm font-medium text-gray-700 mb-1">Tema:</label>
          <select 
            id="tema" 
            name="tema" 
            className="w-full p-2 border rounded" 
            value={temaFiltro}
            onChange={(e) => setTemaFiltro(e.target.value)}
          >
            <option value="">Todos</option>
             {temasUnicos.map(tema => (
              <option key={tema} value={tema}>{tema}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="ano" className="block text-sm font-medium text-gray-700 mb-1">Ano:</label>
          <select 
            id="ano" 
            name="ano" 
            className="w-full p-2 border rounded" 
            value={anoFiltro}
            onChange={(e) => setAnoFiltro(e.target.value)}
          >
            <option value="">Todos</option>
            {anosUnicos.map(ano => (
              <option key={ano} value={ano}>{ano}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="busca" className="block text-sm font-medium text-gray-700 mb-1">Busca Textual:</label>
          <input 
            type="text" 
            id="busca" 
            name="busca" 
            placeholder="Digite palavras-chave..." 
            className="w-full p-2 border rounded" 
            value={buscaFiltro}
            onChange={(e) => setBuscaFiltro(e.target.value)}
          />
        </div>
      </div>

      {/* Legislation List */}
      <div className="space-y-4">
        {documentosFiltrados.map((doc) => (
          <div key={doc.id} className="p-4 border rounded shadow-sm bg-white">
            <h2 className="text-xl font-semibold mb-1">{doc.titulo}</h2>
            <p className="text-sm text-gray-600 mb-2">{doc.tipo} | Tema: {doc.tema} | Ano: {doc.ano} | Publicado em: {doc.data}</p>
            <p className="mb-3 text-gray-800">{doc.ementa}</p>
            <div>
              {doc.linkOficial && (
                <Link href={doc.linkOficial} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline mr-4">
                  Ver no Site Oficial
                </Link>
              )}
              {/* Local link logic can be added here if needed */}
            </div>
          </div>
        ))}
        {documentosFiltrados.length === 0 && (
          <p className="text-center text-gray-500 mt-6">Nenhum documento encontrado com os filtros selecionados.</p>
        )}
      </div>
    </div>
  );
}


import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Sobre | Portal do Inspetor Escolar - MG",
  description: "Informações sobre o Portal do Inspetor Escolar de Minas Gerais.",
};

export default function SobrePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Sobre o Portal do Inspetor Escolar</h1>
      
      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Histórico e Objetivo</h2>
        <p className="mb-3">
          Este portal foi desenvolvido com o objetivo de centralizar e facilitar o acesso às legislações educacionais, diretrizes da Superintendência de Regulação e Inspeção Escolar (SRI) e outras informações essenciais para a atuação dos Inspetores Escolares no estado de Minas Gerais.
        </p>
        <p>
          Buscamos oferecer uma ferramenta prática e didática que auxilie no dia a dia do trabalho da inspeção, promovendo a consulta rápida e organizada das normas vigentes.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Manutenção</h2>
        <p>
          O conteúdo deste portal é atualizado e mantido de forma colaborativa, buscando sempre refletir as publicações mais recentes dos órgãos oficiais.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-3">Links Institucionais</h2>
        <ul className="list-disc pl-5 space-y-2">
          <li>
            <a href="https://www.educacao.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Secretaria de Estado de Educação de Minas Gerais (SEE/MG)
            </a>
          </li>
          <li>
            <a href="https://estudeemcasa.educacao.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Portal Estude em Casa (Educação MG)
            </a>
          </li>
           <li>
            <a href="https://www.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
              Governo do Estado de Minas Gerais
            </a>
          </li>
        </ul>
      </section>
    </div>
  );
}


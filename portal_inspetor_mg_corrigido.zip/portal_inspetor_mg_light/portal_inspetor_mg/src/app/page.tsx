import Link from 'next/link';

export default function HomePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Bem-vindo ao Portal do Inspetor Escolar - MG</h1>
      <p className="mb-4">
        Este portal centraliza as principais legislações educacionais, diretrizes da Superintendência de Regulação e Inspeção Escolar (SRI) e outras informações relevantes para apoiar o trabalho da Inspeção Escolar no estado de Minas Gerais.
      </p>
      
      {/* TODO: Add Search Bar Component Here */}
      <div className="my-8 p-4 border rounded bg-gray-50">
        <h2 className="text-2xl font-semibold mb-4">Busca Rápida</h2>
        <input 
          type="text" 
          placeholder="Pesquisar em todo o portal..." 
          className="w-full p-2 border rounded" 
        />
        {/* Placeholder for search functionality */}
      </div>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Destaques / Últimas Atualizações</h2>
        {/* Placeholder for dynamic content - links to recent legislation/guidelines */}
        <ul className="list-disc pl-5 space-y-2">
          <li>
            <Link href="/legislacao/resolucao-see-4943-2023" className="text-blue-600 hover:underline">
              Resolução SEE Nº 4.943/2023 - Organização Escolar (Exemplo)
            </Link>
          </li>
          <li>
            <Link href="/diretrizes-sri/instrucao-normativa-sa-see-3-2025" className="text-blue-600 hover:underline">
              Instrução Normativa SA/SEE Nº 3/2025 (Exemplo)
            </Link>
          </li>
           <li>
            <Link href="/legislacao/resolucao-cee-495-2023" className="text-blue-600 hover:underline">
              Resolução CEE Nº 495/2023 - Autorização de Funcionamento (Exemplo)
            </Link>
          </li>
          {/* Add more static examples or implement dynamic fetching later */}
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Acesso Rápido</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link href="/legislacao" className="block p-4 border rounded hover:shadow-lg transition-shadow bg-blue-50">
            <h3 className="font-semibold text-lg mb-1">Legislação Educacional</h3>
            <p className="text-sm text-gray-700">Consulte Leis, Decretos, Resoluções, Portarias e mais.</p>
          </Link>
          <Link href="/diretrizes-sri" className="block p-4 border rounded hover:shadow-lg transition-shadow bg-green-50">
            <h3 className="font-semibold text-lg mb-1">Diretrizes da SRI</h3>
            <p className="text-sm text-gray-700">Acesse Instruções Normativas e Orientações da SRI.</p>
          </Link>
          <Link href="/diario-oficial" className="block p-4 border rounded hover:shadow-lg transition-shadow bg-yellow-50">
            <h3 className="font-semibold text-lg mb-1">Diário Oficial (MGDOE)</h3>
            <p className="text-sm text-gray-700">Link e guia para consulta no Jornal Minas Gerais.</p>
          </Link>
        </div>
      </section>
    </div>
  );
}


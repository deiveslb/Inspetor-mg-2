import type { Metadata } from "next";
import Link from 'next/link';

export const metadata: Metadata = {
  title: "Diário Oficial MG (MGDOE) | Portal do Inspetor Escolar - MG",
  description: "Acesso e guia de consulta ao Diário Oficial do Estado de Minas Gerais (MGDOE) para atos da educação.",
};

export default function DiarioOficialPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Diário Oficial do Estado de MG (MGDOE)</h1>
      
      <p className="mb-4">
        O Diário Oficial do Estado de Minas Gerais, também conhecido como Jornal Minas Gerais (MGDOE), é o veículo oficial para a publicação dos atos normativos e administrativos do governo estadual, incluindo os da Secretaria de Estado de Educação (SEE/MG).
      </p>

      <div className="mb-6">
        <Link 
          href="https://www.jornalminasgerais.mg.gov.br/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-blue-600 text-white font-semibold py-2 px-4 rounded hover:bg-blue-700 transition-colors"
        >
          Acessar o MGDOE (Jornal Minas Gerais)
        </Link>
      </div>

      <section>
        <h2 className="text-2xl font-semibold mb-3">Como Pesquisar Atos da Educação no MGDOE</h2>
        <ol className="list-decimal pl-5 space-y-3">
          <li>
            <strong>Acesse o site:</strong> Clique no link acima para abrir o site oficial do Jornal Minas Gerais.
          </li>
          <li>
            <strong>Escolha a Data ou Use a Busca:</strong> Você pode navegar pelas edições por data no calendário ou utilizar a ferramenta de busca avançada (geralmente um ícone de lupa ou um campo de pesquisa).
          </li>
          <li>
            <strong>Filtre por Secretaria (se disponível):</strong> Em algumas interfaces de busca, pode ser possível filtrar por órgão. Procure por "Secretaria de Estado de Educação" ou "Educação".
          </li>
          <li>
            <strong>Use Palavras-chave:</strong> Na busca textual, utilize termos específicos como:
            <ul className="list-disc pl-6 mt-2 space-y-1 text-sm text-gray-800">
              <li>"Resolução SEE Nº [número]"</li>
              <li>"Portaria SEE Nº [número]"</li>
              <li>"Secretaria de Estado de Educação"</li>
              <li>Nome da norma ou assunto (ex: "calendário escolar", "autorização de funcionamento")</li>
            </ul>
          </li>
          <li>
            <strong>Verifique o Caderno Correto:</strong> As publicações oficiais costumam ser divididas em cadernos (Executivo, Legislativo, etc.). Atos da SEE geralmente estão no caderno do Executivo.
          </li>
        </ol>
        <p className="mt-4 text-sm text-gray-600">
          *Nota: A interface e as opções de busca do site do MGDOE podem mudar. As dicas acima são um guia geral.*
        </p>
      </section>
    </div>
  );
}


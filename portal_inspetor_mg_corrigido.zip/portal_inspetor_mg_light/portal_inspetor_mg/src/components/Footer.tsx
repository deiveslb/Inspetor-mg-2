const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-200 text-gray-700 p-4 mt-8">
      <div className="container mx-auto text-center">
        <p className="mb-2">
          Contato SRI: (31) 3915-3309 | sri@educacao.mg.gov.br
        </p>
        <p className="mb-2">
          Links Úteis: 
          <a href="https://www.educacao.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="hover:underline mx-1">SEE/MG</a> |
          <a href="https://www.jornalminasgerais.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="hover:underline mx-1">MGDOE</a> |
          <a href="https://estudeemcasa.educacao.mg.gov.br/" target="_blank" rel="noopener noreferrer" className="hover:underline mx-1">Portal Educação MG</a>
        </p>
        <p className="text-sm">
          &copy; {currentYear} Portal do Inspetor Escolar - MG. Mantido de forma colaborativa.
        </p>
      </div>
    </footer>
  );
};

export default Footer;


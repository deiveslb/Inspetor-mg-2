# Portal do Inspetor Escolar - MG

Este portal centraliza as principais legislações educacionais, diretrizes da Superintendência de Regulação e Inspeção Escolar (SRI) e outras informações relevantes para apoiar o trabalho da Inspeção Escolar no estado de Minas Gerais.

## Tecnologias

- Next.js 15
- React
- TypeScript
- Tailwind CSS
- Shadcn UI

## Instalação

```bash
# Instalar dependências
npm install
# ou
yarn install
# ou
pnpm install

# Iniciar servidor de desenvolvimento
npm run dev
# ou
yarn dev
# ou
pnpm dev
```

Abra [http://localhost:3000](http://localhost:3000) no seu navegador para ver o resultado.

## Deploy na Vercel

A maneira mais fácil de fazer deploy deste projeto é usando a [Plataforma Vercel](https://vercel.com/new?utm_medium=default-template&filter=next.js).

Consulte a [documentação de deploy do Next.js](https://nextjs.org/docs/deployment) para mais detalhes.

## Estrutura do Projeto

- `src/app/` - Páginas da aplicação (Next.js App Router)
- `src/components/` - Componentes reutilizáveis
- `src/hooks/` - Hooks personalizados do React
- `src/lib/` - Funções utilitárias
- `src/data/` - Dados estáticos da aplicação
- `src/types/` - Definições de tipos TypeScript
